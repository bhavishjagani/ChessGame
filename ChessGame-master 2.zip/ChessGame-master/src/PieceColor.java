public enum PieceColor {
    BLACK, WHITE, EMPTY
}